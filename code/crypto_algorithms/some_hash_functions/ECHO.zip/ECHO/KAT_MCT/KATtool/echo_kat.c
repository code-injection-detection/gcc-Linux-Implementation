/* echo_kat.c */

/**********************************************************************************
 * Source file for the KAT tool of the ECHO hash
 * function proposal.
 * Author(s) : Gilles Macario-Rat - Orange Labs - October 2008.
***********************************************************************************
 * Parts of this code are from
 * genKAT.c 
 * authors: NIST
**********************************************************************************/


#define max_(a,b)	(((a) > (b)) ? (a) : (b))
#define min_(a,b)	(((a) < (b)) ? (a) : (b))
#ifdef WIN32
#include <io.h>
#define _dup_  _dup
#define _dup2_ _dup2
#define _fileno_ _fileno
#endif

#ifdef NUX
#include <unistd.h>
#define _dup_  dup
#define _dup2_ dup2
#define _fileno_ fileno
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#include "echo.h"

#define	MAX_MARKER_LEN		50
#define	SUBMITTER_INFO_LEN	128

typedef enum { KAT_SUCCESS = 0, KAT_FILE_OPEN_ERROR = 1, KAT_HEADER_ERROR = 2, KAT_DATA_ERROR = 3, KAT_HASH_ERROR = 4 } STATUS_CODES;

STATUS_CODES	genShortMsg(int hashbitlen);
STATUS_CODES	genLongMsg(int hashbitlen);
STATUS_CODES	genExtremelyLongMsg(int hashbitlen);
STATUS_CODES	genMonteCarlo(int hashbitlen);
STATUS_CODES	genGeneralTest(char * testfile);
int		FindMarker(FILE *infile, const char *marker);
int		FindMarkers(FILE *infile, const char *markers[]);
int		ReadHex(FILE *infile, BitSequence *A, int Length, char *str);
int		ReadHex_(FILE *infile, BitSequence *A, int Length);
void	fprintBstr(FILE *fp, char *S, BitSequence *A, int L);
STATUS_CODES
main(int argc, char *argv[])
{
	int		i, ret_val;
	int  bitlens[4] = { 224, 256, 384, 512 };
	if (argc > 1)
	{
		while (--argc>0)
		{
			if ( (ret_val = genGeneralTest((++argv)[0])) != KAT_SUCCESS )
			{
				return ret_val;
			}
		}
	}
	else
	{
		for ( i=0; i<4; i++ ) {
			if ( (ret_val = genShortMsg(bitlens[i])) != KAT_SUCCESS )
				return ret_val;
			if ( (ret_val = genLongMsg(bitlens[i])) != KAT_SUCCESS )
				return ret_val;
			if ( (ret_val = genExtremelyLongMsg(bitlens[i])) != KAT_SUCCESS )
				return ret_val;
			if ( (ret_val = genMonteCarlo(bitlens[i])) != KAT_SUCCESS )
				return ret_val;
		}
	}
	
	return KAT_SUCCESS;
}

STATUS_CODES
genGeneralTest(char * testfile)
{
	char		fn[32];
	char		lineAN[SUBMITTER_INFO_LEN];
	char		linePS[SUBMITTER_INFO_LEN];
	int			msglen, msgbytelen, msglen2, msgbytelen2, hashlen, hashlens[512], repeat, repeat2, done, complete;
	int			i, level, old, marker;
	int			msglen_read, msg_read, msglen2_read, msg2_read, hashlen_read, nbhashlen, salt_read, repeat_read, repeat2_read, text_read, level_read;
	BitSequence	Msg[4288], Msg2[4288], MD[64];
	BitSequence	Salt[16];
	FILE		*fp_in, *fp_out;
	hashState	state;
	HashReturn	retval;

	char * Markers[] = 
	{
		"Len = ",
		"Msg = ",
		"Salt = ",
		"Repeat = ",
		"Len2 = ",
		"Msg2 = ",
		"Repeat2 = ",
		"Text = ",
		"Level = ",
		"MD = ",
		"HashLen = ",
		"\0"
	};


	sprintf(fn, "%s.txt", testfile);
	if ( (fp_in = fopen(fn, "r")) == NULL ) 
	{
		printf("Couldn't open <%s> for read\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	
	if ( FindMarker(fp_in, "# Algorithm Name:") ) 
	{
		fscanf(fp_in, "%[^\n]\n", lineAN);
	}
	else 
	{
		printf("genGeneralTest: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) 
	{
		fscanf(fp_in, "%[^\n]\n", linePS);
	}
	else 
	{
		printf("genGeneralTest: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}

	hashlen_read = 0;
	if ( FindMarkers(fp_in , Markers) == 10)
	{
		for (nbhashlen = 0; nbhashlen < 512; )
		{
			if (fscanf(fp_in, "%d,", &hashlens[nbhashlen]) != 1)
			{
				break;
			}
			if ((hashlens[nbhashlen]>=128) && (hashlens[nbhashlen]<=512))
			{
				nbhashlen ++;
			}
		}
		if (nbhashlen>0)
		{
			hashlen_read = 1;
		}
	}
	if (!hashlen_read)
	{
		nbhashlen = 4;
		hashlens[0] = 224;
		hashlens[1] = 256;
		hashlens[2] = 384;
		hashlens[3] = 512;
	}

	old =_dup_(1);
	for (i=0; i<nbhashlen; i++)
	{
		rewind(fp_in);
		hashlen = hashlens[i];

		sprintf(fn, "%s_%d.txt", testfile, hashlen);
		if ( (fp_out = fopen(fn, "w")) == NULL ) {
			printf("Couldn't open <%s> for write\n", fn);
			return KAT_FILE_OPEN_ERROR;
		}
		fprintf(fp_out, "# %s\n", fn);
		fprintf(fp_out, "# Algorithm Name:%s\n", lineAN);
		fprintf(fp_out, "# Principal Submitter:%s\n", linePS);
		if (hashlen_read)
		{
			fprintf(fp_out, "\nHashLen = %d,\n", hashlen);
		}
		done = 0;
		do 
		{
			msglen = 0;
			msgbytelen = 0;
			msglen2 = 0;
			msgbytelen2 = 0;
			memset(Salt, 0x00, 16);
			memset(Msg, 0x00, 4288);
			memset(Msg2, 0x00, 4288);
			level = 0;
			repeat = 1;
			repeat2 = 1;
			complete = 0;
			msglen_read = 0;
			msglen2_read = 0;
			msg_read = 0;
			msg2_read = 0;
			salt_read = 0;
			repeat_read = 0;
			repeat2_read = 0;
			text_read = 0;
			level_read = 0;


			do 
			{
				if ( (marker = FindMarkers(fp_in , Markers)) >= 0)
				{
					switch (marker)
					{
					case 0: // "Len = "
						fscanf(fp_in, "%d", &msglen);
						msgbytelen = (msglen+7)/8;
						msglen_read = 1;
						break;
					case 1: // "Msg = "
						ReadHex_(fp_in, Msg, msgbytelen);
						msg_read = 1;
						break;
					case 2: // "Salt = "
#ifdef SALT_OPTION
						ReadHex_(fp_in, Salt, 16);
#endif
						salt_read = 1;
						break;
					case 3: // "Repeat = "
						fscanf(fp_in, "%d", &repeat);
						repeat_read = 1;
						break;
					case 4: // "Len2 = "
						fscanf(fp_in, "%d", &msglen2);
						msgbytelen2 = (msglen2+7)/8;
						msglen2_read = 1;
						break;
					case 5: // "Msg2 = "
						ReadHex_(fp_in, Msg2, msgbytelen2);
						msg2_read = 1;
						break;
					case 6: // "Repeat2 = "
						fscanf(fp_in, "%d", &repeat2);
						repeat2_read = 1;
						break;
					case 7: // "Text = "
						fscanf(fp_in, "%s", Msg);
						msgbytelen = strlen(Msg);
						msglen = 8 * msgbytelen;
						text_read = 1;
						break;
					case 8: // "Level = "
						fscanf(fp_in, "%d", &level);
						level_read = 1;
						break;
					case 9: // "MD = "
						complete = 1;
						break;
					default:
						break;
					}
				}
				else 
				{
					done = 1;
					break;
				}
			}
			while (!complete);
			if (done)
			{
				break;
			}
			fprintf(fp_out, "\n");
			if (msglen_read)
			{
				fprintf(fp_out, "Len = %d\n", msglen);
			}
			if (msg_read)
			{
				fprintBstr(fp_out, "Msg = ", Msg, msgbytelen);
			}
			if (salt_read)
			{
				fprintBstr(fp_out, "Salt = ", Salt, 16);
			}
			if (repeat_read)
			{
				fprintf(fp_out, "Repeat = %d\n", repeat);
			}
			if (msglen2_read)
			{
				fprintf(fp_out, "Len2 = %d\n", msglen2);
			}
			if (msg2_read)
			{
				fprintBstr(fp_out, "Msg2 = ", Msg2, msgbytelen2);
			}
			if (repeat2_read)
			{
				fprintf(fp_out, "Repeat2 = %d\n", repeat2);
			}
			if (text_read)
			{
				fprintf(fp_out, "Text = %s\n", Msg);
			}
			if (level_read)
			{
				fprintf(fp_out, "Level = %d\n", level);
#ifdef TRACE
				SetLevelTrace(level);
#endif
			}
			fflush( fp_out );
			_dup2_(_fileno_(fp_out), 1);
			if ( (retval = Init(&state, hashlen)) != KAT_SUCCESS ) {
				fflush( stdout );
				_dup2_(old, 1);
				printf("Init returned <%d> in genGeneralTest\n", retval);
				return KAT_HASH_ERROR;
			}
#ifdef SALT_OPTION
			if ( (retval = SetSalt(&state, Salt)) != KAT_SUCCESS ) 
			{
				fflush( stdout );
				_dup2_(old, 1);
				printf("SetSalt returned <%d> in genGeneralTest\n", retval);
				return KAT_HASH_ERROR;
			}
#endif
			for ( ; repeat > 0 ; repeat --)
			{
				if ( (retval = Update(&state, Msg, msglen)) != KAT_SUCCESS ) 
				{
					fflush( stdout );
					_dup2_(old, 1);
					printf("Update returned <%d> in genGeneralTest\n", retval);
					return KAT_HASH_ERROR;
				}
			}
			for ( ; repeat2 > 0 ; repeat2 --)
			{
				if ( (retval = Update(&state, Msg2, msglen2)) != KAT_SUCCESS ) 
				{
					fflush( stdout );
					_dup2_(old, 1);
					printf("Update returned <%d> in genGeneralTest\n", retval);
					return KAT_HASH_ERROR;
				}
			}
			if ( (retval = Final(&state, MD)) != KAT_SUCCESS ) 
			{
				fflush( stdout );
				_dup2_(old, 1);
				printf("Final returned <%d> in genGeneralTest\n", retval);
				return KAT_HASH_ERROR;
			}
			fflush( stdout );
			fprintBstr(fp_out, "MD = ", MD, (hashlen+7)/8);
			fflush( fp_out );			
		} while ( !done );
		fclose(fp_out);
		_dup2_(old, 1);
		printf("finished %s for <%d>\n", testfile, hashlen);
		fflush( stdout );
	}
	
	fclose(fp_in);	
	return KAT_SUCCESS;
}
STATUS_CODES
genShortMsg(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	int			msglen, msgbytelen, done;
	BitSequence	Msg[256], MD[64];
	FILE		*fp_in, *fp_out;
	
	if ( (fp_in = fopen("ShortMsgKAT.txt", "r")) == NULL ) {
		printf("Couldn't open <ShortMsgKAT.txt> for read\n");
		return KAT_FILE_OPEN_ERROR;
	}
	
	sprintf(fn, "ShortMsgKAT_%d.txt", hashbitlen);
	if ( (fp_out = fopen(fn, "w")) == NULL ) {
		printf("Couldn't open <%s> for write\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(fp_out, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("genShortMsg: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Principal Submitter:%s\n", line);
	}
	else {
		printf("genShortMsg: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
	
	done = 0;
	do {
		if ( FindMarker(fp_in, "Len = ") )
			fscanf(fp_in, "%d", &msglen);
		else {
			done = 1;
			break;
		}
		msgbytelen = (msglen+7)/8;

		if ( !ReadHex(fp_in, Msg, msgbytelen, "Msg = ") ) {
			printf("ERROR: unable to read 'Msg' from <ShortMsgKAT.txt>\n");
			return KAT_DATA_ERROR;
		}
		Hash(hashbitlen, Msg, msglen, MD);
		fprintf(fp_out, "\nLen = %d\n", msglen);
		fprintBstr(fp_out, "Msg = ", Msg, msgbytelen);
		fprintBstr(fp_out, "MD = ", MD, hashbitlen/8);
	} while ( !done );
	printf("finished ShortMsgKAT for <%d>\n", hashbitlen);
	
	fclose(fp_in);
	fclose(fp_out);
	
	return KAT_SUCCESS;
}

STATUS_CODES
genLongMsg(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	int			msglen, msgbytelen, done;
	BitSequence	Msg[4288], MD[64];
	FILE		*fp_in, *fp_out;
	
	if ( (fp_in = fopen("LongMsgKAT.txt", "r")) == NULL ) {
		printf("Couldn't open <LongMsgKAT.txt> for read\n");
		return KAT_FILE_OPEN_ERROR;
	}
	
	sprintf(fn, "LongMsgKAT_%d.txt", hashbitlen);
	if ( (fp_out = fopen(fn, "w")) == NULL ) {
		printf("Couldn't open <%s> for write\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(fp_out, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("genLongMsg: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Principal Submitter:%s\n\n", line);
	}
	else {
		printf("genLongMsg: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
	
	done = 0;
	do {
		if ( FindMarker(fp_in, "Len = ") )
			fscanf(fp_in, "%d", &msglen);
		else
			break;
		msgbytelen = (msglen+7)/8;

		if ( !ReadHex(fp_in, Msg, msgbytelen, "Msg = ") ) {
			printf("ERROR: unable to read 'Msg' from <LongMsgKAT.txt>\n");
			return KAT_DATA_ERROR;
		}
		Hash(hashbitlen, Msg, msglen, MD);
		fprintf(fp_out, "\nLen = %d\n", msglen);
		fprintBstr(fp_out, "Msg = ", Msg, msgbytelen);
		fprintBstr(fp_out, "MD = ", MD, hashbitlen/8);
	} while ( !done );
	printf("finished LongMsgKAT for <%d>\n", hashbitlen);
	
	fclose(fp_in);
	fclose(fp_out);
	
	return KAT_SUCCESS;
}

STATUS_CODES
genExtremelyLongMsg(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	BitSequence	Text[65], MD[64];
	int			i, repeat;
	FILE		*fp_in, *fp_out;
	hashState	state;
	HashReturn	retval;
	
	if ( (fp_in = fopen("ExtremelyLongMsgKAT.txt", "r")) == NULL ) {
		printf("Couldn't open <ExtremelyLongMsgKAT.txt> for read\n");
		return KAT_FILE_OPEN_ERROR;
	}
	
	sprintf(fn, "ExtremelyLongMsgKAT_%d.txt", hashbitlen);
	if ( (fp_out = fopen(fn, "w")) == NULL ) {
		printf("Couldn't open <%s> for write\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(fp_out, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("genExtremelyLongMsg: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Principal Submitter:%s\n\n", line);
	}
	else {
		printf("genExtremelyLongMsg: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
	
	if ( FindMarker(fp_in, "Repeat = ") )
		fscanf(fp_in, "%d", &repeat);
	else {
		printf("ERROR: unable to read 'Repeat' from <ExtremelyLongMsgKAT.txt>\n");
		return KAT_DATA_ERROR;
	}
	
	if ( FindMarker(fp_in, "Text = ") )
		fscanf(fp_in, "%s", Text);
	else {
		printf("ERROR: unable to read 'Text' from <ExtremelyLongMsgKAT.txt>\n");
		return KAT_DATA_ERROR;
	}
	
//	memcpy(Text, "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno", 64);
	
	if ( (retval = Init(&state, hashbitlen)) != KAT_SUCCESS ) {
		printf("Init returned <%d> in genExtremelyLongMsg\n", retval);
		return KAT_HASH_ERROR;
	}
	for ( i=0; i<repeat; i++ )
		if ( (retval = Update(&state, Text, 512)) != KAT_SUCCESS ) {
			printf("Update returned <%d> in genExtremelyLongMsg\n", retval);
			return KAT_HASH_ERROR;
		}
	if ( (retval = Final(&state, MD)) != KAT_SUCCESS ) {
		printf("Final returned <%d> in genExtremelyLongMsg\n", retval);
		return KAT_HASH_ERROR;
	}
	fprintf(fp_out, "Repeat = %d\n", repeat);
	fprintf(fp_out, "Text = %s\n", Text);
	fprintBstr(fp_out, "MD = ", MD, hashbitlen/8);
	printf("finished ExtremelyLongMsgKAT for <%d>\n", hashbitlen);
	
	fclose(fp_in);
	fclose(fp_out);
	
	return KAT_SUCCESS;
}

STATUS_CODES
genMonteCarlo(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	BitSequence	Seed[128], Msg[128], MD[64], Temp[128];
	int			i, j, bytelen;
	FILE		*fp_in, *fp_out;
	
	if ( (fp_in = fopen("MonteCarlo.txt", "r")) == NULL ) {
		printf("Couldn't open <MonteCarlo.txt> for read\n");
		return KAT_FILE_OPEN_ERROR;
	}
	
	sprintf(fn, "MonteCarlo_%d.txt", hashbitlen);
	if ( (fp_out = fopen(fn, "w")) == NULL ) {
		printf("Couldn't open <%s> for write\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(fp_out, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("genMonteCarlo: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(fp_out, "# Principal Submitter:%s\n\n", line);
	}
	else {
		printf("genMonteCarlo: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
	
	if ( !ReadHex(fp_in, Seed, 128, "Seed = ") ) {
		printf("ERROR: unable to read 'Seed' from <MonteCarlo.txt>\n");
		return KAT_DATA_ERROR;
	}
	
	bytelen = hashbitlen / 8;
	memcpy(Msg, Seed, 128);
	fprintBstr(fp_out, "Seed = ", Seed, 128);
	for ( j=0; j<100; j++ ) {
		for ( i=0; i<1000; i++ ) {
			Hash(hashbitlen, Msg, 1024, MD);
			memcpy(Temp, Msg, 128-bytelen);
			memcpy(Msg, MD, bytelen);
			memcpy(Msg+bytelen, Temp, 128-bytelen);
		}
		fprintf(fp_out, "\nj = %d\n", j);
		fprintBstr(fp_out, "MD = ", MD, bytelen);
	}
	printf("finished MonteCarloKAT for <%d>\n", hashbitlen);

	fclose(fp_in);
	fclose(fp_out);
	
	return KAT_SUCCESS;
}

//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int
FindMarker(FILE *infile, const char *marker)
{
	char	line[MAX_MARKER_LEN];
	int		i, len;

	len = (int)strlen(marker);
	if ( len > MAX_MARKER_LEN-1 )
		len = MAX_MARKER_LEN-1;

	for ( i=0; i<len; i++ )
		if ( (line[i] = fgetc(infile)) == EOF )
			return 0;
	line[len] = '\0';

	while ( 1 ) {
		if ( !strncmp(line, marker, len) )
			return 1;

		for ( i=0; i<len-1; i++ )
			line[i] = line[i+1];
		if ( (line[len-1] = fgetc(infile)) == EOF )
			return 0;
		line[len] = '\0';
	}

	// shouldn't get here
	return 0;
}

int 
FindMarkers(FILE *infile, const char *markers[])
{
	char	line[MAX_MARKER_LEN];
	int		i, j, len, minlen;

	i = 0;
	minlen = MAX_MARKER_LEN-1;
	while (markers[i][0])
	{
		len = (int)strlen(markers[i]);
		if ( len > MAX_MARKER_LEN-1 )
		{
			len = MAX_MARKER_LEN-1;
		}
		if (len<minlen)
		{
			minlen = len;
		}
		i++;
	}
	len = minlen;

	for ( i=0; i<len; i++ )
		if ( (line[i] = fgetc(infile)) == EOF )
			return -1;
	line[len] = '\0';

	while ( 1 ) {
		i = 0;
		while (markers[i][0])
		{
			if ( !strncmp(line, markers[i], min_(strlen(line), strlen(markers[i]))) )
			{
				for (j=(int)min_(strlen(line), strlen(markers[i])); j<(int)strlen(markers[i]); j++)
				{
					if ( (line[j] = fgetc(infile)) == EOF )
					{
						return 0;
					}
					if (line[j] != markers[i][j])
					{
						break;
					}
				}
				if (j==strlen(markers[i]))
				{
					return i;
				}
				line[j+1] = '\0';
			}
			i++;
		}

		len = (int)strlen(line);
		for ( i=0; i<len-1; i++ )
			line[i] = line[i+1];
		if (len == minlen)
		{
			if ( (line[len-1] = fgetc(infile)) == EOF )
				return -1;
		}
		else
		{
			line[len-1] = '\0';
		}
	}

	// shouldn't get here
	return 0;
}

//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int
ReadHex(FILE *infile, BitSequence *A, int Length, char *str)
{
	int			i, ch, started;
	BitSequence	ich;

	if ( Length == 0 ) {
		A[0] = 0x00;
		return 1;
	}
	memset(A, 0x00, Length);
	started = 0;
	if ( FindMarker(infile, str) )
		while ( (ch = fgetc(infile)) != EOF ) {
			if ( !isxdigit(ch) ) {
				if ( !started ) {
					if ( ch == '\n' )
						break;
					else
						continue;
				}
				else
					break;
			}
			started = 1;
			if ( (ch >= '0') && (ch <= '9') )
				ich = ch - '0';
			else if ( (ch >= 'A') && (ch <= 'F') )
				ich = ch - 'A' + 10;
			else if ( (ch >= 'a') && (ch <= 'f') )
				ich = ch - 'a' + 10;
			
			for ( i=0; i<Length-1; i++ )
				A[i] = (A[i] << 4) | (A[i+1] >> 4);
			A[Length-1] = (A[Length-1] << 4) | ich;
		}
	else
		return 0;

	return 1;
}

int
ReadHex_(FILE *infile, BitSequence *A, int Length)
{
	int			i, ch, started;
	BitSequence	ich;

	if ( Length == 0 ) {
		A[0] = 0x00;
		return 1;
	}
	memset(A, 0x00, Length);
	started = 0;
	while ( (ch = fgetc(infile)) != EOF ) {
		if ( !isxdigit(ch) ) {
			if ( !started ) {
				if ( ch == '\n' )
					break;
				else
					continue;
			}
			else
				break;
		}
		started = 1;
		if ( (ch >= '0') && (ch <= '9') )
			ich = ch - '0';
		else if ( (ch >= 'A') && (ch <= 'F') )
			ich = ch - 'A' + 10;
		else if ( (ch >= 'a') && (ch <= 'f') )
			ich = ch - 'a' + 10;
		
		for ( i=0; i<Length-1; i++ )
			A[i] = (A[i] << 4) | (A[i+1] >> 4);
		A[Length-1] = (A[Length-1] << 4) | ich;
	}
	return 1;
}

void
fprintBstr(FILE *fp, char *S, BitSequence *A, int L)
{
	int		i;

	fprintf(fp, "%s", S);

	for ( i=0; i<L; i++ )
		fprintf(fp, "%02X", A[i]);

	if ( L == 0 )
		fprintf(fp, "00");

	fprintf(fp, "\n");
}
