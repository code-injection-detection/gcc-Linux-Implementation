 Contents					Description
---------------				------------------------------------------------
echo_kat.c					Source to generate KAT files for required digest sizes and 
							various other parameters. To be compiled with the ECHO
							hash algorithm API.


Readme_echo_kat.txt			This file

							Source file of the ECHO algorithm API
---------------				------------------------------------------------
echo_ref.c
echo.h

echo_32.c
echo.h

echo_64.c
echo.h

							Sample input files for ECHO_KAT.exe
---------------				------------------------------------------------
SaltKAT.txt					Input file for KAT test with various Salt values
IntermediateKAT1.txt		Input file for KAT test to demonstrate one and two block 
							messages for hash length 224 and 256
IntermediateKAT2.txt		Input file for KAT test, idem as above for hash length 384 and 512
TableKAT.txt				Input file for KAT test to demonstrate all 8 bit values for the
							AES tables.

							Result of ECHO_KAT.exe with above input files
---------------				------------------------------------------------
SaltKAT_224.txt
SaltKAT_252.txt
SaltKAT_384.txt
SaltKAT_512.txt
TableKAT_224.txt
TableKAT_252.txt
TableKAT_384.txt
TableKAT_512.txt
IntermediateKAT1_224.txt
IntermediateKAT1_252.txt
IntermediateKAT2_384.txt
IntermediateKAT2_512.txt




Directions
------------------

1. The echo_kat.c source file is intended to be an extent of the genKAT tool of 
	the NIST.
	Without argument echo_kat behaves like genKAT, that is it produces the 
	suite of NIST KAT tests
	With one or more arguments, each argument is interpreted as the base name of 
	a new KAT test file.
	
2. Compilation
	For the compilation, several symbols may be defined, which affects the 
	behavior of the tool.
	WIN32 : Required if the target platform is Windows
	NUX	: Required if the target platform is LINUX and UNIX
	Exactly one of the two previous symbols must be defined.
	SALT_OPTION : Required for demonstrating various values of the salt.
	Makes use of function "SetSalt"
	TRACE : Required for outputing intermediate values of the compression function.
	Makes use of function "SetLevelTrace"
	
3. SALT_OPTION
	Since the ECHO hash algorithm can use a Salt argument,
	there is a function named "SetSalt" that can set the value of the Salt.
	By default the value of the Salt is 128 "0" bits.
	This option is available for the three implementations. (reference and optimized
	versions)
	The salt can be set within the input file just after 

4. TRACE
	In order to visualize the internal state of the Compress function of the
	ECHO algorithm, the reference implementation has a feature of trace which
	ouputs the content of internal variables used by the Compression function.
	This option is not implemented on the optimized versions.
	The level of detail of the traces can be tuned by a value that can be set
	within the input test file just after the keyword "Level =".
	By default the value of the level is "0".
	According to the value of this level, we have the following level of detail:
	0 : no traces are ouput
	1 : value of the counter and the internal state at the begining of the compression function
	and value of the internal state at the end of the compression function
	2 : same as 1, plus value of the internal state at the end of each round of
	the compression function
	3 : same as 2, plus value of the internal state at the end of each 
	BIG_SUB_WORDS, BIG_SIFT_ROWS, BIG_MIX_COLUMNS functions.
	4 : same as 3, plus value of the 16 128-bit words after each round of AES
	and detailed computations of the BIG_FINAL.
	
5. Example of input test file for the ECHO_KAT tool.


# Test.txt
# Algorithm Name: ECHO
# Principal Submitter: Henri Gilbert

//syntax of the ShortMsgKAT and LongMsgKAT is suported

Len = 128
Msg = 00000000000000000000000000000000
MD = ??

//syntax of the ExtremelyLongMsg is also suported

Repeat = 1000
Text = abcd
MD = ??

//Setting the salt

Len = 128
Msg = 52A608AB21CCDD8A4457A57EDE782176
Salt = 01000000000000000000000000000000
MD = ??

//Setting the level of detail

Len = 872
Msg = 758EA3FEA738973DB0B8BE7E599BBEF4519373D6E6DCD7195EA885FC991D896762992759C2A09002912FB08E0CB5B76F49162AEB8CF87B172CF3AD190253DF612F77B1F0C532E3B5FC99C2D31F8F65011695A087A35EE4EEE5E334C369D8EE5D29F695815D866DA99DF3F79403
Level = 4
MD = ??

//mixing the options is possible

Repeat = 10
Text = abcd
Salt = 01000000000000000000000000000000
Level = 1
MD = ??





