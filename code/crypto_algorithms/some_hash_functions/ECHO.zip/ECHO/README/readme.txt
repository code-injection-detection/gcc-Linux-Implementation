Submission of ECHO by Orange Labs
==================================

This CD contains the following files.

\README\readme.txt : this file.

\Reference_Implementation 

	echo_ref.c 	: the source code for the reference implementation.
	echo.h 		: the header file for echo_ref.c.

\Optimized_32bit 

	echo_32.c 	: the source code for the 32-bit optimized implementation of ECHO.
	echo.h 		: the header file for the 32-bit optimized implementation of ECHO.

\Optimized_64bit 

	echo_64.c 	: source code for the 64-bit optimized implementation of ECHO.
	echo.h 		: header file for the 64-bit optimized implementation of ECHO.

\KAT_MCT 

	\KAT_Tests 

		12 files containing the results of the NIST KAT tests 

		ShortMsgKAT_224.txt
		ShortMsgKAT_256.txt
		ShortMsgKAT_384.txt
		ShortMsgKAT_512.txt
		LongMsgKAT_224.txt
		LongMsgKAT_256.txt
		LongMsgKAT_384.txt
		LongMsgKAT_512.txt
		ExtremelyLongMsgKAT_224.txt
		ExtremelyLongMsgKAT_256.txt
		ExtremelyLongMsgKAT_384.txt
		ExtremelyLongMsgKAT_512.txt

	\MCT_Tests 

		4 files containing the results of the NIST MonteCarlo tests 

		MonteCarlo_224.txt
		MonteCarlo_256.txt
		MonteCarlo_384.txt
		MonteCarlo_512.txt

	\TableKAT
		
		
		4 files containing the results of additional table testing KAT. 
		Every input to the 256-byte AES table is exercised in this test. The results were
		generated using the tool echo_kat.c that is included on this disc along with 
		the input file TableKAT.txt.

		TableKAT_224.txt
		TableKAT_256.txt
		TableKAT_384.txt
		TableKAT_512.txt

	\IntermediateKAT

		4 files containing the intermediate values for one and two block message inputs for each of the four NIST 
		hash output lengths. The results were generated using the tool echo_kat.c included on this disc along with 
		the two input files IntermediateKAT1.txt and IntermediateKAT2.txt

		IntermediateKAT1_224.txt
		IntermediateKAT1_256.txt
		IntermediateKAT2_384.txt
		IntermediateKAT2_512.txt

	\SaltKAT

		4 files containing the KAT outputs when exercising the salt. A fixed message is hashed with 16 different 
		salt values for each of the NIST hash output lengths. The results were generated using the tool echo_kat.c 
		included on this disc along with the input file SaltKAT.txt.

		SaltKAT_224.txt
		SaltKAT_256.txt
		SaltKAT_384.txt
		SaltKAT_512.txt

	\KATtool

		echo_kat.c		: source code for tool for all required and optional KAT/MCT tests.
		Readme_echo_kat.txt 	: README file for echo_kat.c tool.

		Four input tables are also provided:

		TableKAT.txt 		: Input file to generate all files in \TableKAT
		SaltKAT.txt 		: Input file to generate all files in \SaltKAT
		IntermediateKAT1.txt 	: Input file to generate two files in \IntermediateKAT
		IntermediateKAT2.txt 	: Input file to generate two files in \IntermediateKAT

\Supporting_Documentation

	echo_description.pdf 	: ECHO specifications and accompanying analysis.



