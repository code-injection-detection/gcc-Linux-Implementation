#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "echo.h"

#define ECHO_HASH_256(data,databitlen,hashval) Hash(256,data,databitlen,hashval) 


void print_buffer(char * buffer,int n)
{
	int i;
	for (int i = 0; i < n; i++)
	{
		printf("%02X ", buffer[i] & 0xff);
	}
	printf("\n");
}

int main(int argc, char*argv[])
{
	char bytes_to_hash[1000];
	char hash_value[32];
	
	memset(bytes_to_hash,0,1000);
	printf("%lu\n",strlen(argv[1]));
	memcpy(bytes_to_hash,argv[1],strlen(argv[1]));
	print_buffer(bytes_to_hash,10);
	ECHO_HASH_256(bytes_to_hash,strlen(argv[1])*8,hash_value);
	print_buffer(hash_value,32);
	
	memset(bytes_to_hash,0,15);
	bytes_to_hash[0]=0xcc;
	ECHO_HASH_256(bytes_to_hash,8,hash_value);
	print_buffer(hash_value,32);
	
	memset(bytes_to_hash,0,15);
	bytes_to_hash[0]=0x98;
	ECHO_HASH_256(bytes_to_hash,7,hash_value);
	print_buffer(hash_value,32);
	
	
	
	return 0;
}
